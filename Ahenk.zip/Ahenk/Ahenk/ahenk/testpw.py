import subprocess
import sys



filePath = 'C:\\Users\\Public\\script\\6262939f-e2ac-4667-8fc6-a987ecb4c850.ps1'
process = subprocess.Popen([r'powershell.exe',
                            '-ExecutionPolicy',
                            'Unrestricted', filePath, ""], stderr=subprocess.PIPE, stdout=subprocess.PIPE)

#
result_code = process.wait()
p_out = process.stdout.read().decode("unicode_escape")
p_err = process.stderr.read().decode("unicode_escape")

print(result_code)
print(p_out)
print(p_err)

#
# process = subprocess.Popen("Write-Host \"Hello, World!\"", stdout=subprocess.PIPE, shell=True)
# print(process.stdout.read())


