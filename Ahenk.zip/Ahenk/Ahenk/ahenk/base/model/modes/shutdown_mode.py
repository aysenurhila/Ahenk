#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Author: Volkan Şahin <volkansah.in> <bm.volkansahin@gmail.com>


class ShutdownMode(object):
    def __init__(self):
        pass

    @property
    def obj_name(self):
        return "SHUTDOWN_MODE"
