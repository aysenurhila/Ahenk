#!/usr/bin/python3
# -*- coding: utf-8 -*-


def info():
    inf = dict()
    inf['name'] = 'script'
    inf['version'] = '1.0.0'
    inf['support'] = 'debian'
    inf['description'] = ''
    inf['task'] = True
    inf['user_oriented'] = False
    inf['machine_oriented'] = False
    inf['developer'] = ''

    return inf