#!/usr/bin/python3
# -*- coding: utf-8 -*-
# Author: Mine DOGAN <mine.dogan@agem.com.tr>
# Author: Emre Akkaya <emre.akkaya@agem.com.tr>


from base.plugin.abstract_plugin import AbstractPlugin
import json, os
import traceback
from PIL import ImageGrab

class TakeScreenshot(AbstractPlugin):
    def __init__(self, data, context):
        super(TakeScreenshot, self).__init__()
        self.data = data
        self.context = context
        self.logger = self.get_logger()
        self.message_code = self.get_message_code()

        self.temp_file_name = str(self.generate_uuid())
        self.shot_path = '{0}{1}.png'.format(str(self.Ahenk.received_dir_path()), self.temp_file_name)

    def handle_task(self):
        try:

            try:
                os.remove(self.shot_path)
            except Exception:
                pass

            snapshot = ImageGrab.grab()
            snapshot.save(self.shot_path)
            if self.is_exist(self.shot_path):
                self.logger.debug('Screenshot file found.')

                data = {}
                md5sum = self.get_md5_file(str(self.shot_path))
                self.logger.debug('{0} renaming to {1}'.format(self.temp_file_name, md5sum))
                self.rename_file(self.shot_path, self.Ahenk.received_dir_path() + md5sum)
                self.logger.debug('Renamed.')
                data['md5'] = md5sum
                self.context.create_response(code=self.message_code.TASK_PROCESSED.value,
                                             message='Ekran görüntü9sü başarıyla alındı.',
                                             data=json.dumps(data),
                                             content_type=self.get_content_type().IMAGE_JPEG.value)
                self.logger.debug('SCREENSHOT task is handled successfully')
            else:
                raise Exception('Image not found this path: {0}'.format(self.shot_path))

        except Exception as e:
            self.logger.error(
                'A problem occured while handling SCREENSHOT task: {0}'.format(traceback.format_exc()))
            self.context.create_response(code=self.message_code.TASK_ERROR.value,
                                         message='Ekran görüntüsü alırken hata oluştu: {0}'.format(str(e)))


def handle_task(task, context):
    screenshot = TakeScreenshot(task, context)
    screenshot.handle_task()